-- DQL for trainers to view members without full access to all member's information
CREATE VIEW Members_View AS
    SELECT first_name, last_name, email, gender, age
        FROM Members;
INSERT INTO Trainers VALUES (1, 'tom', 'kendall', '613 342 0908', 'kendall@yahoo.com', 'm', 'kendall@99', 'Africa01');
INSERT INTO Trainers VALUES (2, 'Shannon', 'Micheals', '613 120 7283', 'shannon@hotmail.com', 'o', 'cannon01', 'Marvel_12');
INSERT INTO Trainers VALUES (3, 'Linda', 'Emerald', '514 892 6534', 'emerald@hotmail.com', 'f', 'emerald_city', 'diamonds99');
INSERT INTO Trainers VALUES (4, 'David', 'Fabian', '450 682 7108', 'david101@hotmail.com', 'm', 'david101', 'alaska99');

INSERT INTO Rooms VALUES(1, 101, 'bicycle room', '2024-04-10 10:00 AM');
INSERT INTO Rooms VALUES(2, 220, 'fitness A', '2024-04-13 01:00 PM');
INSERT INTO Rooms VALUES(3, 113, 'fitness B', '2024-01-02 02:20 PM');
INSERT INTO Rooms VALUES(4, 365, 'Weights room', '2024-04-01 12:30 PM');
INSERT INTO Rooms VALUES(5, 210, 'zumba class', '2024-04-15 04:00 PM');

INSERT INTO Sessions VALUES(1, '2024-04-26 02:15 pm', 'p', 2, 2, true);
INSERT INTO Sessions VALUES(2, '2024-02-09 09:00 am', 'p', 1, 3, false);
INSERT INTO Sessions VALUES(3, '2024-04-01 11:00 am', 'g', 3, 1, true);
INSERT INTO Sessions VALUES(4, '2024-04-01 11:00 am', 'g', 3, 5, true);

INSERT INTO Members VALUES (1, 'synthia', 'vincent de paul', '514 825 7122', 'synthiavdp@gmail.com', 'f', 23, 'synthiavdp', 'hello12', 1);
INSERT INTO Members VALUES (2, 'gerald', 'hammons', '418 897 6452', 'gerald01@hotmail.com', 'm', 56, 'gerald01', 'Ottawa_0', 3);
INSERT INTO Members VALUES (3, 'rick', 'mercy', '418 222 9108', 'mercy@hotmail.com', 'm', 61, 'fitness13', 'MercyOnMe', 3);
INSERT INTO Members VALUES (4, 'patrick', 'Polide', '514 453 0910', 'polide@yahoo.com', 'm', 19, 'patrick5', 'rolex!00', 3);
INSERT INTO Members VALUES (5, 'anna', 'clover', '450 341 1009', 'clover99@hotmail.com', 'o', 34, 'smiley11', 'Panel_09', 2);
INSERT INTO Members VALUES (6, 'larysa', 'amalia', '613 980 4356', 'amalaia@gmail.com', 'f', 26, 'larysa97', 'oscar_06');
INSERT INTO Members VALUES (7, 'maria', 'simmons', '613 222 8733', 'maria01@hotmail.com', 'o', 34, 'sunshine05', 'Daisies_0');

INSERT INTO Administrators VALUES (1, 'Riley', 'Collins', '450 810 9921', 'riley@videotron.ca', 'riley45', 'happy_3');
INSERT INTO Administrators VALUES (2, 'Amy', 'Richards', '514 522 0022', 'happy-amy@gmail.ca', 'happydays', 'Canada99');
INSERT INTO Administrators VALUES (3, 'Zoe', 'Avery', '613 112 6448', 'avery_3@videotron.ca', 'gym_club', 'admin_11');

INSERT INTO Bills VALUES (1, '2024-03-14', '2024-04-14', '2024-04-28', false, 12.99, 0.0, 0.0, 0.0, 0.0, 1);
INSERT INTO Bills VALUES (2, '2024-03-30', '2024-04-30', '2024-05-14', true, 12.99, 0.0, 0.0, 0.0, 0.0, 2);
INSERT INTO Bills VALUES (3, '2023-01-02', '2024-02-02', '2024-03-16', true, 12.99, 0.0, 0.0, 0.0, 0.0, 4);
INSERT INTO Bills VALUES (4, '2024-02-02', '2024-03-02', '2024-03-16', true, 12.99, 0.0, 0.0, 0.0, 0.0, 4);
INSERT INTO Bills VALUES (5, '2024-03-02', '2024-04-02', '2024-04-16', false, 12.99, 0.0, 0.0, 0.0, 0.0, 4);
INSERT INTO Bills VALUES (6, '2024-04-13', '2024-05-13', '2024-05-27', false, 12.99, 0.0, 0.0, 0.0, 0.0, 5);
INSERT INTO Bills VALUES (7, '2024-04-13', '2024-05-13', '2024-05-27', false, 12.99, 0.0, 0.0, 0.0, 0.0, 6);
INSERT INTO Bills VALUES (8, '2024-04-13', '2024-05-13', '2024-05-27', false, 12.99, 0.0, 0.0, 0.0, 0.0, 7);

INSERT INTO Goals VALUES (1, 'I want to lose weight by the end of this month. My brother is getting married next month so I want to look good for the wedding.', true, 1);
INSERT INTO Goals VALUES (2, 'I am hoping to gain weight by a few months. At least around . My doctor told me that my weight is unhealthy and that I am too thin.', false, 2);
INSERT INTO Goals VALUES (3, 'I would like to lose weight in my face. Maybe I need to cut on bread and pasta.', false, 1);
INSERT INTO Goals VALUES (4, 'I need to get better mentally and physically. I want to gain muscles in my arms.', false, 3);
INSERT INTO Goals VALUES (5, 'Last month I gained 3 pounds. I need to lose it now.', false, 5);
INSERT INTO Goals VALUES (6, 'I want to lose 3 pounds in 2 weeks.', false, 5);

INSERT INTO Health VALUES (1, 104, 5.2, 0, 0, 1);
INSERT INTO Health VALUES (2, 132, 5.5, 0, 0, 6);
INSERT INTO Health VALUES (3, 121, 5.3, 30, 0, 7);
INSERT INTO Health VALUES (4, 142, 5.2, 0, 0, 3);
INSERT INTO Health VALUES (5, 100, 5.2, 0, 5, 4);

INSERT INTO Credit_Cards VALUES(1, 'VISA', 'Synthia Vincent De Paul', '9453 4007 9154 0088', '01', '29', '512', 1);
INSERT INTO Credit_Cards VALUES(2, 'Mastercard', 'Tim Hammons', '2342 0354 2895 1039', '02', '25', '512', 2);
INSERT INTO Credit_Cards VALUES(3, 'Mastercard', 'Rick Mercy', '9345 9572 3058 5022', '01', '27', '512', 3);
INSERT INTO Credit_Cards VALUES(4, 'VISA', 'Patrick Polide', '2846 7732 9630 1839', '01', '29', '299', 4);
INSERT INTO Credit_Cards VALUES(5, 'American express', 'Patrick Polide', '8453 7582 4938 3028', '01', '24', '108', 5);

INSERT INTO Equipments VALUES(1, 'treadmill1', 'low', 2);
INSERT INTO Equipments VALUES(2, 'treadmill2', 'low', 3);
INSERT INTO Equipments VALUES(3, 'bicyle#1', 'high', 1);
INSERT INTO Equipments VALUES(4, 'bicyle#2', 'high', 1);
INSERT INTO Equipments VALUES(5, 'abs machine', 'high', 2);
INSERT INTO Equipments VALUES(6, 'dumbells', 'high', 4);
-- CREATE DATABASE FitnessClubManagementSystem;
-- USE FitnessClubManagementSystem;    
CREATE TABLE Trainers
       (trainer_id          SERIAL PRIMARY KEY,
        first_name          VARCHAR(25) NOT NULL,
        last_name           VARCHAR(50) NOT NULL,
        phone_number        CHAR(19) NOT NULL, 
        email               VARCHAR(50) NOT NULL UNIQUE, 
        gender              CHAR(1),
        username            VARCHAR(15) NOT NULL UNIQUE,
        password            VARCHAR(15) NOT NULL
       );

CREATE TABLE Rooms
       (room_id             SERIAL PRIMARY KEY,
        room_number         INTEGER,
        room_name           VARCHAR(25),
        not_available       TIMESTAMP
       );
       
CREATE TABLE Sessions
       (session_id         SERIAL PRIMARY KEY,
        session_date       TIMESTAMP,
        training_type       CHAR(1),
        trainer_id          INTEGER REFERENCES Trainers(trainer_id),
        room_id             INTEGER REFERENCES Rooms(room_id),
        available           BOOLEAN DEFAULT TRUE
       );

CREATE TABLE Members
       (member_id           SERIAL PRIMARY KEY,
        first_name          VARCHAR(25) NOT NULL,
        last_name           VARCHAR(50) NOT NULL,
        phone_number        CHAR(19) NOT NULL, 
        email               VARCHAR(50) NOT NULL UNIQUE, 
        gender              CHAR(1),
        age		            INT,
        username            VARCHAR(15) NOT NULL UNIQUE,
        password            VARCHAR(15) NOT NULL,
        session_id          INTEGER REFERENCES Sessions(session_id)
       );

CREATE TABLE Administrators
       (administrator_id    SERIAL PRIMARY KEY,
        first_name          VARCHAR(25) NOT NULL,
        last_name           VARCHAR(50) NOT NULL,
        phone_number        CHAR(19) NOT NULL, 
        email               VARCHAR(50) NOT NULL UNIQUE, 
        username            VARCHAR(15) NOT NULL UNIQUE,
        password            VARCHAR(15) NOT NULL            
       );
             
CREATE TABLE Bills
       (bill_id              	SERIAL PRIMARY KEY,
        bill_start_date      	DATE DEFAULT CURRENT_DATE,
        bill_end_date		    DATE,
        payment_due		        DATE,
        payment_status          BOOLEAN,
        membership_fee          NUMERIC(4,2),
        personal_training_fee   NUMERIC(4,2) DEFAULT 0.0,
        group_class_fee         NUMERIC(4,2) DEFAULT 0.0,
        tax 			        NUMERIC(5,2) DEFAULT 0.0,
        total                   NUMERIC(6,2) DEFAULT 0.0,
        member_id               INTEGER REFERENCES Members(member_id)
       ); 
       
CREATE TABLE Goals
       (goal_id         SERIAL PRIMARY KEY,
        description     VARCHAR(255),
        achieved        BOOLEAN,
        member_id		INT REFERENCES Members(member_id)
       );
       
CREATE TABLE Health
       (health_id       SERIAL PRIMARY KEY,
        weight	        INT,
        height    	    NUMERIC(2,1),
        weight_lost	    INT,
        weight_gained	INT,
        member_id	    INTEGER REFERENCES Members(member_id)
       );
       
CREATE TABLE Credit_Cards
       (credit_card_id	    SERIAL PRIMARY KEY,
        card_type 	        VARCHAR(20),
        cardholder_name	    VARCHAR(35) NOT NULL,
        card_number	        CHAR(19) NOT NULL,
        expiry_month	    CHAR(2) NOT NULL,
        expiry_year		    CHAR(2) NOT NULL,
        cvv_code	        INTEGER NOT NULL,
        member_id		    INTEGER REFERENCES Members(member_id)
       );  
      
CREATE TABLE Equipments
       (equipment_id        SERIAL PRIMARY KEY,
        equipment_name      VARCHAR(25),
        equipment_status    VARCHAR(10),
        room_id             INTEGER REFERENCES Rooms(room_id)
       );
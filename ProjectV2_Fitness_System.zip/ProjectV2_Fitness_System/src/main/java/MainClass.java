import java.sql.*; // import the sql
import java.util.Scanner;  // import the Scanner class

import static java.lang.System.exit;

public class MainClass {
    // global static variable for database connection
    private static Connection connection;

    // constructor for the main class
    public MainClass() {
        String url = "jdbc:postgresql://localhost:5432/FitnessClubManagementSystem";
        String user = "postgres";
        String password = "louis";

        try {
            Class.forName("org.postgresql.Driver");
            connection = DriverManager.getConnection(url, user, password);
            if (connection != null) {
                System.out.println("Connected to the database");
            } else {
                System.out.println("Failed to connect to the database");
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static String getUserInput(Scanner scanner) {
        String answer;

        while (true) {
            System.out.print("Do you have an account? ");
            answer = scanner.next();
            // if the user entered "yes"
            if (answer.equalsIgnoreCase("yes")) {
                break;

            }
            // if the user entered "no"
            else if (answer.equalsIgnoreCase("no")) {
                break;
            }
            // else the user did not enter a correct answer
            System.out.println("Sorry we didn't understand that please respond with yes or no.");

        }

        return answer;
    }

    public static void deleteUser(User user) throws SQLException {
        Scanner scanner = new Scanner(System.in);

        boolean isValidUser = user.deleteAccount();
        while(!isValidUser) {
            System.out.println("Invalid password. Try again.");
            isValidUser = user.deleteAccount();
        }
        System.out.print("Are you sure you want to delete your account? ");
        String answer = scanner.next();
        if(answer.equalsIgnoreCase("yes")) {
            user.deleteAccount();
            exit(0);
        }
    }
    public static String mainMenu(Scanner scanner) {
        System.out.println("Welcome to the Health And Fitness Club Management System!");
        //System.out.println("If you want to quit the system, enter \"exit\" anytime.");

        String typeOfUser = "";

        while (typeOfUser.equals("")) {
            System.out.print("Are you a member (enter m), trainer (enter t) or administrator (enter a)? ");
            char userType = scanner.nextLine().toLowerCase().charAt(0);

            // if user is a member
            if (userType == 'm') {
                typeOfUser = "Members";
            }
            // if user is a trainer
            else if (userType == 't') {
                typeOfUser = "Trainers";
            }
            // else user is a administrator
            else if (userType == 'a') {
                typeOfUser = "Administrators";
            } else {
                System.out.println("Invalid response.");
                typeOfUser = "";
            }
        }
        System.out.println("Welcome " + typeOfUser + "!");
        return typeOfUser;
    }

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        String typeOfUser = mainMenu(scanner);

        String answer = getUserInput(scanner);
        scanner.nextLine();
        User user = new User(typeOfUser);

        // else the user entered "no", create an account
        if (answer.equalsIgnoreCase("no")) {
            System.out.println("Let's create one then!");
            boolean isValid;
            String firstName, lastName, phoneNumber, email, username, password;
            String strGender;
            char gender = 0;
            int age = 0;

            do {
                Scanner scanner2 = new Scanner(System.in);
                System.out.print("Enter your first name: ");
                firstName = scanner2.nextLine();
                System.out.print("Enter your last name: ");
                lastName = scanner2.nextLine();
                System.out.print("Enter your phone number (format: xxx xxx xxxx): ");
                phoneNumber = scanner2.nextLine();
                System.out.print("Enter your email: ");
                email = scanner2.nextLine();
                System.out.print("Enter your gender (male, female, other): ");
                strGender = scanner2.nextLine();
                if(typeOfUser.equals("Members") || typeOfUser.equals("Trainers")) {
                    if (strGender.equalsIgnoreCase("male")) {
                        gender = 'm';
                    } else if (strGender.equalsIgnoreCase("female")) {
                        gender = 'f';
                    } else if (strGender.equalsIgnoreCase("other")) {
                        gender = 'o';
                    }
                }
                if(typeOfUser.equals("Members")) {
                    System.out.println("Enter your age: ");
                    age = scanner2.nextInt();
                }
                System.out.print("Enter your username: ");
                username = scanner.nextLine();
                System.out.print("Enter your password: ");
                password = scanner.nextLine();

                isValid = user.isValidInputs(firstName, lastName, phoneNumber, email, gender, username, password, age);
            } while (!isValid);

            try {
                if (typeOfUser.equals("Members")) {
                    if (user.signUpMember(firstName.toLowerCase(), lastName.toLowerCase(), phoneNumber, email, gender, age, username, password))
                        System.out.println("Sign up was successful.");
                    else {
                        System.out.println("Error: Sign up was not successful.");
                        exit(1);
                    }
                }
                else if(typeOfUser.equals("Trainers")){
                    if(user.signUpTrainer(firstName, lastName, phoneNumber, email, gender, username, password))
                        System.out.println("Sign up was successful.");
                    else {
                        System.out.println("Error: Sign up was not successful.");
                        exit(1);
                    }
                }
                else {
                    if(user.signUpAdmin(firstName, lastName, phoneNumber, email, username, password))
                        System.out.println("Sign up was successful.");
                    else {
                        System.out.println("Error: Sign up was not successful.");
                        exit(1);
                    }
                }
            } catch (Exception e) {
                System.out.println(e);
            }
        }
        try {
            System.out.print("\nEnter your username: ");
            String username = scanner.nextLine();
            System.out.print("Enter your password: ");
            String password = scanner.nextLine();

            if (user.logIn(username, password)) {
                System.out.println("Login was successful.");
            } else {
                System.out.println("Error: Login was not successful.");
                exit(1);
            }

            if (typeOfUser.equals("Members")) {
                int choice;
                do {
                    System.out.println("\nChoose from the following menu:\n" +
                                        "\t(1) health metrics\n" +
                                        "\t(2) goals\n" +
                                        "\t(3) personal information\n" +
                                        "\t(4) manage sessions\n" +
                                        "\t(5) pay or view bill\n" +
                                        "\t(6) delete account\n" +
                                        "\t(0) exit");
                    choice = scanner.nextInt();

                    if (choice == 1) {
                        // display the user's health information
                        int weight = user.displayHealth();
                        System.out.println("Would you like to modify this data?");
                        answer = scanner.next();
                        if (answer.equalsIgnoreCase("yes")) {
                            boolean modified = user.modifyHealth(weight);
                            if(modified)
                                System.out.println("Your new health information was successfully modified");
                        }
                    } else if (choice == 2) {
                        user.displayGoal();
                        System.out.println("Would you like to add, modify or delete any entry?");
                        answer = scanner.next();
                        if (answer.equalsIgnoreCase("add"))
                            user.addGoal();
                        else if (answer.equalsIgnoreCase("modify"))
                            user.modifyGoal();
                        else if(answer.equalsIgnoreCase("delete"))
                            user.deleteGoal();
                    }
                    else if (choice == 3) {
                        boolean isValidUser = user.displayPersonalInfoM();
                        while(!isValidUser) {
                            System.out.println("Invalid password. Try again.");
                            isValidUser = user.displayPersonalInfoM();
                        }
                        System.out.println("Would you like to update your information?");
                        answer = scanner.next();
                        if (answer.equalsIgnoreCase("yes"))
                            user.modifyPersonalInfo();
                    }
                    else if(choice == 4) {
                        user.manageSessionsM();
                    }
                    else if(choice == 5) {
                        user.membersManageBills();
                    }
                    else if(choice == 6) {
                        deleteUser(user);
                    }
                    else if(choice != 0)
                        System.out.println("Invalid option. Please try again.");
                } while (choice != 0);
            }
            else if (typeOfUser.equals("Trainers")) {
                int choice;
                do {
                    System.out.print("\nChoose from the following menu:\n" +
                                    "\t(1) personal information\n" +
                                    "\t(2) add session\n" +
                                    "\t(3) view members\n" +
                                    "\t(4) delete account\n" +
                                    "\t(0) exit\n");
                    choice = scanner.nextInt();

                    if(choice == 1) {
                        boolean isValidUser = user.displayPersonalInfoT();
                        while(!isValidUser) {
                            System.out.println("Invalid password. Try again.");
                            isValidUser = user.displayPersonalInfoT();
                        }
                        System.out.println("Would you like to update your information?");
                        answer = scanner.next();
                        if (answer.equalsIgnoreCase("yes"))
                            user.modifyPersonalInfo();
                    }
                    else if (choice == 2) {
                        user.addSession();
                    }
                    else if (choice == 3) {
                        Scanner scanner1 = new Scanner(System.in);
                        System.out.println("Enter the member's first name: ");
                        String firstName = scanner1.nextLine();
                        System.out.println("Enter the member's last name: ");
                        String lastName = scanner1.nextLine();
                        user.viewMembersT(firstName.toLowerCase(), lastName.toLowerCase());
                    }
                    else if (choice == 4) {
                        deleteUser(user);
                    }
                } while(choice != 0);
            }
            else {
                int choice;
                do {
                    System.out.println("\nChoose from the following menu:\n" +
                                        "\t(1) personal information\n" +
                                        "\t(2) equipments\n" +
                                        "\t(3) billing\n" +
                                        "\t(4) update fees\n" +
                                        "\t(5) room booking\n" +
                                        "\t(6) update session\n" +
                                        "\t(7) delete account\n" +
                                        "\t(0) exit\n");
                    choice = scanner.nextInt();

                    if (choice == 1) {
                        boolean isValidUser = user.displayPersonalInfoA();
                        while(!isValidUser) {
                            System.out.println("Invalid password. Try again.");
                            isValidUser = user.displayPersonalInfoA();
                        }
                        System.out.println("Would you like to update your information?");
                        answer = scanner.next();
                        if (answer.equalsIgnoreCase("yes"))
                            user.modifyPersonalInfo();
                    }
                    else if(choice == 2) {
                        user.displayEquipments();
                        System.out.println("Would you like to add, modify or delete any entry?");
                        answer = scanner.next();
                        if (answer.equalsIgnoreCase("add"))
                            user.addEquipment();
                        else if (answer.equalsIgnoreCase("modify"))
                            user.modifyEquipment();
                        else
                            user.deleteEquipment();
                    }
                    else if(choice == 3) {
                        user.displayBills();
                        user.adminManageBills();
                    }
                    else if(choice == 4) {
                        Scanner scanner1 = new Scanner(System.in);
                        System.out.println("Current membership fee: " + user.getMembershipFee());
                        System.out.println("Current personal training fee: " + user.getPersonalTrainingFee());
                        System.out.println("Current group class fee: " + user.getGroupClassFee());

                        System.out.println("Which fees would you like to update?\n" +
                                            "\t(m) membership fees\n" +
                                            "\t(p) personal training fee\n" +
                                            "\t(g) group class fee\n");
                        answer = scanner1.nextLine();

                        if(answer.equalsIgnoreCase("m")) {
                            System.out.println("Enter the new value for membership fee: ");
                            Double membershipFee = scanner1.nextDouble();
                            user.setMembershipFee(membershipFee);
                            System.out.println("Membership fee successfully updated!");
                        }
                        else if(answer.equalsIgnoreCase("p")) {
                            System.out.println("Enter the new value for personal training fee: ");
                            Double personalTrainingFee = scanner1.nextDouble();
                            user.setMembershipFee(personalTrainingFee);
                            System.out.println("Personal training fee successfully updated!");
                        }
                        else if(answer.equalsIgnoreCase("g")) {
                            System.out.println("Enter the new value for group class fee: ");
                            Double groupClassFee = scanner1.nextDouble();
                            user.setMembershipFee(groupClassFee);
                            System.out.println("Group class fee successfully updated!");
                        }
                        else {
                            System.out.println("Sorry invalid response.");
                        }
                    }
                    else if(choice == 5) {
                        user.bookRoom();
                    }
                    else if(choice == 6) {
                    }
                    else if (choice == 7) {
                        deleteUser(user);
                    }
                } while(choice != 0);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
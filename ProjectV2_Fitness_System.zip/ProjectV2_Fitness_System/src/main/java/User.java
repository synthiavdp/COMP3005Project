import java.awt.desktop.SystemSleepEvent;
import java.math.BigDecimal;
import java.sql.*; // import the sql
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Scanner;

public class User {
    private String userType; // type of users are member/trainer/administration
    private static Connection connection;
    Scanner scanner = new Scanner(System.in);
    private String idName;
    private int id;
    private Double membershipFee;
    private Double personalTrainingFee;
    private Double groupClassFee;


    public User(String userType) {
        String url = "jdbc:postgresql://localhost:5432/FitnessClubManagementSystem";
        String user = "postgres";
        String password = "louis";
        this.userType = userType;
        if (userType.equals("Members"))
            idName = "member_id";
        else if (userType.equals("Trainers"))
            idName = "trainer_id";
        else
            idName = "administrator_id";

        this.membershipFee = 12.99;
        this.personalTrainingFee = 21.99;
        this.groupClassFee = 15.99;

        try {
            Class.forName("org.postgresql.Driver");
            connection = DriverManager.getConnection(url, user, password);
            if (connection != null) {
                System.out.println("Connected to the database");
            } else {
                System.out.println("Failed to connect to the database");
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    // getter method to return membership fee
    public Double getMembershipFee() {
        return membershipFee;
    }

    // getter method to return membership fee
    public Double getPersonalTrainingFee() {
        return personalTrainingFee;
    }

    // getter method to return membership fee
    public Double getGroupClassFee() {
        return groupClassFee;
    }

    // setter method for membership fee
    public void setMembershipFee(Double membership_fee) {
        this.membershipFee = membership_fee;
    }

    // setter method for personal training fee
    public void setPersonalTrainingFee(Double personal_training_fee) {
        this.personalTrainingFee = personal_training_fee;
    }

    // setter method for group class fee
    public void setGroupClassFee(Double personal_training_fee) {
        this.groupClassFee = personal_training_fee;
    }

    // add bill to the user's account
    public boolean addBill() throws SQLException {
        Statement statement = connection.createStatement();
        // set the end date to one month from now
        LocalDate end_date = LocalDate.now();
        end_date = end_date.plusMonths(1);
        Date bill_end_date = Date.valueOf(end_date);

        LocalDate payment_date = end_date;
        payment_date = end_date.plusWeeks(2);
        Date payment_due = Date.valueOf(payment_date);

        String insertStatement = "INSERT INTO Bills (payment_status, bill_end_date, payment_due, member_id) VALUES \n" +
                "(false, " + bill_end_date + "', " + ", " + getMembershipFee() + ", " + getMembershipFee() + ", '" + payment_due + ", " + id + "');";
        int rowsInserted = statement.executeUpdate(insertStatement);
        // if rows were inserted
        if (rowsInserted > 0) {
            return true;
        }
        return false;
    }

    public void membersManageBills() throws SQLException {
        Statement statement = connection.createStatement();
        statement.executeQuery("SELECT *\n" +
                "FROM Bills\n" +
                "WHERE member_id = " + id + ";");
        ResultSet resultSet = statement.getResultSet();
        int counter = 0;
        LocalDate curr_date = LocalDate.now();
        Date current = Date.valueOf(curr_date);

        while (resultSet.next()) {
            System.out.println("Bill (" + ++counter + ")");
            int bill_id = resultSet.getInt("bill_id");
            System.out.println("Bill number: #B" + bill_id);
            System.out.println("Start date: " + resultSet.getDate("bill_start_date"));
            Date end_date = resultSet.getDate("bill_end_date");
            System.out.println("End date: " + end_date);
            Date payment_due = resultSet.getDate("payment_due");
            System.out.println("Payment due: " + payment_due);
            boolean payed = resultSet.getBoolean("payment_status");
            System.out.println("Payment status: " + payed);
            System.out.println("Total: $" + resultSet.getBigDecimal("total"));
            System.out.println("Member fee: $" + resultSet.getBigDecimal("membership_fee"));
            System.out.println("Personal trainer fee: $" + resultSet.getBigDecimal("personal_training_fee"));
            System.out.println("Group class fee: $" + resultSet.getBigDecimal("group_class_fee"));
            System.out.println("Tax: $" + resultSet.getBigDecimal("tax"));
            // if the bill date has ended and the member has not payed
            if (end_date.compareTo(current) <= 0 && !payed) {
                System.out.println("Payment is due " + payment_due);
                System.out.println("Would you like to pay?");
                String answer = scanner.nextLine();
                if (answer.equalsIgnoreCase("yes")) {
                    if (processPayment()) {
                        System.out.println("Payment successful!");
                        String updateStatement = "UPDATE Bills\n" +
                                "SET payment_status = " + true +
                                "\nWHERE bill_id = " + bill_id + ";";
                        int rowsUpdated = statement.executeUpdate(updateStatement);
                        // if rows were updated
                        if (rowsUpdated > 0) {
                            System.out.println("Bill ID (" + bill_id + ") was updated successfully!");
                        }
                    } else {
                        System.out.println("Payment was not successful please try again.");
                    }
                }
            }
        }
    }

    public void displayBills() throws SQLException {
        Statement statement = connection.createStatement();
        statement.executeQuery("SELECT *\n" +
                "FROM Bills\n");

        ResultSet resultSet = statement.getResultSet();
        int counter = 0;
        while (resultSet.next()) {
            System.out.println("Bill (" + ++counter + ")");
            int bill_id = resultSet.getInt("bill_id");
            System.out.println("Bill number: #B" + bill_id);
            System.out.println("Start date: " + resultSet.getDate("bill_start_date"));
            System.out.println("End date: " + resultSet.getDate("bill_end_date"));
            System.out.println("Payment due: " + resultSet.getDate("payment_due"));
            System.out.println("Payment status: " + resultSet.getBoolean("payment_status"));
            System.out.println("Total: $" + resultSet.getBigDecimal("total"));
            System.out.println("Member fee: $" + resultSet.getBigDecimal("membership_fee"));
            System.out.println("Personal trainer fee: $" + resultSet.getBigDecimal("personal_training_fee"));
            System.out.println("Group class fee: $" + resultSet.getBigDecimal("group_class_fee"));
            System.out.println("Tax: $" + resultSet.getBigDecimal("tax"));
            System.out.println("Would you like to oversee a bill?");
            String answer = scanner.nextLine();
            if (answer.equalsIgnoreCase("yes")) {
                statement.executeUpdate("UPDATE Bills\n" +
                                            "SET payment_status = " + true +
                                            "\nWHERE bill_id = " + bill_id + ";");
            }
        }

    }

    public void adminManageBills() throws SQLException {
        Statement statement = connection.createStatement();
        statement.executeQuery("SELECT *\n" +
                "FROM Bills\n");

        ResultSet resultSet = statement.getResultSet();
        while (resultSet.next()) {
        }
    }

    private boolean processPayment() throws SQLException {
        Statement statement = connection.createStatement();
        statement.executeQuery("SELECT *\n" +
                "FROM Credit_Cards\n" +
                "WHERE member_id = " + id + ";");
        ResultSet resultSet = statement.getResultSet();
        if (resultSet.next()) {
            return true;
        }
        // else add a credit card
        System.out.println("You don't have a credit card registered with us.");
        System.out.println("We don't accept debit. But we accept credit cards like VISA, Mastercard, American Express.");
        System.out.println("Enter your credit card type: ");
        String card_type = scanner.nextLine();
        if (!(card_type.equalsIgnoreCase("visa") || card_type.equalsIgnoreCase("mastercard") || card_type.equalsIgnoreCase("american express"))) {
            System.out.println("Sorry we don't accept this card type.");
            System.out.println("We don't accept debit. But we accept credit cards like VISA, Mastercard, American Express.");
            System.out.println("Enter your credit card type: ");
            card_type = scanner.nextLine();
        }
        System.out.println("Enter the cardholder's name: ");
        String cardholder_name = scanner.nextLine();
        System.out.println("Enter the card number (with spaces)");
        String card_number = scanner.nextLine();
        System.out.println("Enter the card's expiry month: ");
        String expiry_month = scanner.nextLine();
        if (expiry_month.compareTo("24") < 0) {
            System.out.println("Your card has expired. Please enter another one.");
            System.out.println("Enter the card's expiry month: ");
            expiry_month = scanner.nextLine();
        }
        System.out.println("Enter the card's expiry year: ");
        String expiry_year = scanner.nextLine();
        System.out.println("Enter the card's cvv code (on the back of the card): ");
        String cvv_code = scanner.nextLine();

        String insertStatement = "INSERT INTO Credit_Cards (card_type, cardholder_name, card_number, expiry_month, expiry_year, cvv_code, member_id) VALUES \n" +
                "(" + card_type + ", " + cardholder_name + ", " + card_number + ", " + expiry_month + ", " + expiry_year + ", " + cvv_code + ", " + id + ");";
        int rowsInserted = statement.executeUpdate(insertStatement);
        // if rows were inserted
        if (rowsInserted > 0) {
            return true;
        }
        return false;
    }

    // Takes arguments and uses that information to create a new member
    // Returns true if user was successfully inserted and false if it was not
    public boolean signUpMember(String firstName, String lastName, String phoneNumber, String email, char gender, int age, String username, String password) throws SQLException {
        boolean successful;
        Statement statement = connection.createStatement();
        String insertStatement = "INSERT INTO " + userType + " (first_name, last_name, phone_number, email, gender, age, username, password) VALUES\n" +
                "('" + firstName + "', '" + lastName + "', '" + phoneNumber + "', '" + email + "', '" + gender + "', " + age + ", '" + username + "', '" + password + "');";
        int rowsInserted = statement.executeUpdate(insertStatement);
        statement.executeQuery("SELECT *\n" +
                "FROM " + userType +
                "\nWHERE username = '" + username + "' AND password = '" + password + "';");
        ResultSet resultSet = statement.getResultSet();
        if (resultSet.next())
            id = resultSet.getInt(idName);

        boolean billAdded = addBill();
        // if rows were inserted
        if (rowsInserted > 0 && billAdded) {
            successful = true;
        } else {
            successful = false;
        }
        return successful;
    }

    // Takes arguments and uses that information to create a new trainer
    // Returns true if user was successfully inserted and false if it was not
    public boolean signUpTrainer(String firstName, String lastName, String phoneNumber, String email, char gender, String username, String password) throws SQLException {
        boolean successful;
        Statement statement = connection.createStatement();
        String insertStatement = "INSERT INTO " + userType + " (first_name, last_name, phone_number, email, gender, username, password) VALUES\n" +
                "('" + firstName + "', '" + lastName + "', '" + phoneNumber + "', '" + email + "', '" + gender + "', '" + username + "', '" + password + "');";
        int rowsInserted = statement.executeUpdate(insertStatement);
        statement.executeQuery("SELECT *\n" +
                "FROM " + userType +
                "\nWHERE username = '" + username + "' AND password = '" + password + "';");
        ResultSet resultSet = statement.getResultSet();
        if (resultSet.next())
            id = resultSet.getInt(idName);


        // if rows were inserted
        if (rowsInserted > 0) {
            successful = true;
        } else {
            successful = false;
        }
        return successful;
    }

    // Takes arguments and uses that information to create a new trainer
    // Returns true if user was successfully inserted and false if it was not
    public boolean signUpAdmin(String firstName, String lastName, String phoneNumber, String email, String username, String password) throws SQLException {
        boolean successful;
        Statement statement = connection.createStatement();
        String insertStatement = "INSERT INTO " + userType + " (first_name, last_name, phone_number, email, username, password) VALUES\n" +
                "('" + firstName + "', '" + lastName + "', '" + phoneNumber + "', '" + email + "', '" + username + "', '" + password + "');";
        int rowsInserted = statement.executeUpdate(insertStatement);
        statement.executeQuery("SELECT *\n" +
                "FROM " + userType +
                "\nWHERE username = '" + username + "' AND password = '" + password + "';");
        ResultSet resultSet = statement.getResultSet();
        if (resultSet.next())
            id = resultSet.getInt(idName);


        // if rows were inserted
        if (rowsInserted > 0) {
            successful = true;
        } else {
            successful = false;
        }
        return successful;
    }

    // Takes arguments and uses that information to check if the user exists in the system to log in
    // Returns true if user exists and false if they do not
    public boolean logIn(String username, String password) throws SQLException {
        Statement statement = connection.createStatement();
        boolean userExists;

        statement.executeQuery("SELECT *\n" +
                "FROM " + userType +
                "\nWHERE username = '" + username + "' AND password = '" + password + "';");
        ResultSet resultSet = statement.getResultSet();
        if (resultSet.next()) {
            userExists = true;
            id = resultSet.getInt(idName);
            System.out.println("Welcome " + resultSet.getString("first_name") + "!");
        } else {
            userExists = false;
        }

        return userExists;
    }

    public boolean deleteAccount() throws SQLException {
        Statement statement = connection.createStatement();
        String deleteStatement = "DELETE FROM " + userType + "\n" +
                "WHERE " + idName + " = " + id + ";";

        statement.executeQuery("SELECT *\n" +
                "FROM " + userType +
                "\nWHERE member_id = " + id + ";");
        ResultSet resultSet = statement.getResultSet();
        System.out.println("Enter password: ");
        String password = scanner.nextLine();
        while (resultSet.next()) {
            if (password.equals(resultSet.getString("password"))) {
                int rowsDeleted = statement.executeUpdate(deleteStatement);
                if (rowsDeleted > 0) {
                    System.out.println("Your account was deleted successfully.");
                    return true;
                } else {
                    System.out.println("Your account was not deleted.");
                    return false;
                }
            }
        }
        // if the password does not match return false
        return false;
    }

    // Check if the given input arguments are valid
    // Returns true if they are and false otherwise.
    public boolean isValidInputs(String firstName, String lastName, String phoneNumber, String email, char gender, String username, String password, int age) {
        // if any of the values are empty
        if (firstName.isEmpty() || lastName.isEmpty() || email.isEmpty() || gender == 0 || username.isEmpty() || password.isEmpty()) {
            System.out.println("One of the inputs is empty.");
            return false;
        }

        // go through the first name and check if it contains a number
        char[] charsF = firstName.toCharArray();
        for (char c : charsF) {
            if (Character.isDigit(c)) {
                System.out.println("Your first name contains a number.");
                return false;
            }
        }

        // go through the last name and check if it contains a number
        char[] charsL = lastName.toCharArray();
        for (char c : charsL) {
            if (Character.isDigit(c)) {
                System.out.println("Your last name contains a number.");
                return false;
            }
        }

        // check if the gender is valid
        if (!(gender == 'm' || gender == 'f' || gender == 'o')) {
            System.out.println("The gender must be male, female, or other");
            return false;
        }

        // check if email contains @ character
        if (!(email.contains("@"))) {
            System.out.println("Enter a valid email.");
            return false;
        }

        // if the username or password is too long
        if (username.length() <= 5) {
            System.out.println("Username is too short, must be 15 characters or less.");
            return false;
        }
        if (password.length() <= 5) {
            System.out.println("Password is too short, must be 15 characters or less.");
            return false;
        }
        return true;
    }

    // display member's health
    public int displayHealth() throws SQLException {
        Statement statement = connection.createStatement();
        statement.executeQuery("SELECT weight, height, weight_lost, weight_gained \n" +
                "FROM Health\n" +
                "WHERE member_id = " + id + ";");
        ResultSet resultSet = statement.getResultSet();
        if (!resultSet.next()) {
            System.out.println("You have no data in this area yet.");
            addHealth();
        }
        System.out.println("Health data:");
        // since a member only has one health information no need for a while loop
        int weight = resultSet.getInt("weight");
        System.out.println("Weight: " + resultSet.getInt("weight") + "kg");
        System.out.println("Height: " + resultSet.getBigDecimal("height") + "ft in");
        System.out.println("Weight lost: " + resultSet.getInt("weight_lost") + "kg");
        System.out.println("Weight gained: " + resultSet.getInt("weight_gained") + "kg\n");
        // return the weight to compare the previous weight with the new one if modified by the user
        return weight;
    }

    // add member's health
    public void addHealth() throws SQLException {
        Statement statement = connection.createStatement();
        scanner = new Scanner(System.in);

        System.out.println("Enter your weight in kg: ");
        int weight = scanner.nextInt();
        System.out.println("Enter your height in ft in: ");
        BigDecimal height = scanner.nextBigDecimal();

        String insertStatement = "INSERT INTO Health (weight, height, member_id) VALUES\n" +
                "('" + weight + "', '" + height + "', " + id + ");";
        int rowsInserted = statement.executeUpdate(insertStatement);
        // if rows were inserted
        if (rowsInserted > 0) {
            System.out.println("Your health information was added successfully!");
        } else {
            System.out.println("Your health information failed to add.");
        }
    }

    public boolean modifyHealth(int previousWeight) throws SQLException {
        Scanner scanner1 = new Scanner(System.in);
        Statement statement = connection.createStatement();

        System.out.println("What would you like to modify? (weight or height or both)");
        String answer = scanner1.nextLine();
        if (answer.equalsIgnoreCase("weight")) {
            System.out.println("Enter your new weight: ");
            int newWeight = scanner1.nextInt();
            if (newWeight < previousWeight) {
                statement.executeUpdate("UPDATE Health\n" +
                        "SET weight = " + newWeight +
                        ",\nweight_lost = " + (previousWeight - newWeight) +
                        ",\nweight_gained = " + 0);
            } else if (newWeight > previousWeight) {
                statement.executeUpdate("UPDATE Health\n" +
                        "SET weight = " + newWeight +
                        ",\nweight_gained = " + (newWeight - previousWeight) +
                        ",\nweight_lost = " + 0);

            }
            return true;
        } else if (answer.equalsIgnoreCase("height")) {
            System.out.println("Enter your new height: ");
            BigDecimal newHeight = scanner1.nextBigDecimal();
            statement.executeUpdate("UPDATE Health\n" +
                    "SET height = " + newHeight + ";");
            return true;
        } else if (answer.equalsIgnoreCase("both")) {
            System.out.println("Enter your new weight: ");
            int newWeight = scanner1.nextInt();
            System.out.println("Enter your new height: ");
            BigDecimal newHeight = scanner1.nextBigDecimal();
            if (newWeight < previousWeight) {
                statement.executeUpdate("UPDATE Health\n" +
                        "SET weight = " + newWeight +
                        ",\n height = " + newHeight +
                        ",\nweight_lost = " + (previousWeight - newWeight) +
                        ",\nweight_gained = " + 0);
            } else if (newWeight > previousWeight) {
                statement.executeUpdate("UPDATE Health\n" +
                        "SET weight = " + newWeight +
                        ",\n height = " + newHeight +
                        ",\nweight_gained = " + (previousWeight - newWeight) +
                        ",\nweight_lost = " + 0);
            }
            return true;
        }

        System.out.println("Sorry I didn't understand what you wrote.");
        return false;
    }

    public void modifyGoal() {

    }

    // add member's goal
    public void addGoal() throws SQLException {
        Statement statement = connection.createStatement();
        scanner = new Scanner(System.in);

        System.out.println("Enter your goal's description: ");
        String description = scanner.nextLine();
        System.out.println("Have you achieved this goal yet? ");
        String answer = scanner.nextLine();

        boolean achieved;
        if (answer.equalsIgnoreCase("yes")) {
            achieved = true;
            System.out.println("Wow, congratulations!");
        } else {
            achieved = false;
            System.out.println("That's okay, you can do it. Good luck!");
        }

        String insertStatement = "INSERT INTO Goals (description, achieved, member_id) VALUES\n" +
                                "('" + description + "', " + achieved + ", " + id + ");";
        int rowsInserted = statement.executeUpdate(insertStatement);
        // if rows were inserted
        if (rowsInserted > 0) {
            System.out.println("Your goal was added successfully!");
        } else {
            System.out.println("Your goal information failed to add.");
        }

    }

    // display the member's goal
    public void displayGoal() throws SQLException {
        Statement statement = connection.createStatement();
        statement.executeQuery("SELECT * \n" +
                "FROM Goals\n" +
                "WHERE member_id = '" + id + "';");

        ResultSet resultSet = statement.getResultSet();
        if (!resultSet.next()) {
            System.out.println("You have no data in this area yet.");
            addGoal();
        } else {
            System.out.println("Goal data:");
            // since a member can have 1 or more multiple goals use a do/while loop
            do {
                System.out.println("Goal id: " + resultSet.getInt("goal_id"));
                System.out.println("Description: " + resultSet.getString("description"));
                System.out.println("Achieved: " + resultSet.getBoolean("achieved") + "\n");
            } while (resultSet.next());
        }
    }

    public void deleteGoal() throws SQLException {
        Statement statement = connection.createStatement();
        scanner = new Scanner(System.in);
        System.out.println("Enter the goal id that you want to delete: ");
        int goal_id = scanner.nextInt();
        String deleteStatement = "DELETE FROM Goals\n" +
                "WHERE goal_id = '" + goal_id + "';";
        int rowsDeleted = statement.executeUpdate(deleteStatement);
        // if rows were deleted
        if (rowsDeleted > 0)
            System.out.println("Goal ID ( " + goal_id + " ) was deleted successfully!");
        else
            System.out.println("Goal was not deleted.");
    }

    public void modifyPersonalInfo() {

    }

    // displays the member's information
    public boolean displayPersonalInfoM() throws SQLException {
        scanner = new Scanner(System.in);
        Statement statement = connection.createStatement();
        statement.executeQuery("SELECT *\n" +
                "FROM " + userType +
                "\nWHERE member_id = " + id + ";");
        ResultSet resultSet = statement.getResultSet();
        System.out.println("Enter password to view: ");
        String password = scanner.nextLine();
        while (resultSet.next()) {
            if (password.equals(resultSet.getString("password"))) {
                // display the user information
                System.out.println("\nFirst name: " + resultSet.getString("first_name"));
                System.out.println("Last name: " + resultSet.getString("last_name"));
                System.out.println("Phone number: " + resultSet.getString("phone_number"));
                System.out.println("Age: " + resultSet.getInt("age"));
                System.out.print("Gender: ");
                if ((resultSet.getString("gender")).charAt(0) == 'f')
                    System.out.println("female");
                else if ((resultSet.getString("gender")).charAt(0) == 'f')
                    System.out.println("male");
                else
                    System.out.println("other");
                System.out.println("Email: " + resultSet.getString("email"));
                System.out.println("Username: " + resultSet.getString("username"));
                System.out.println("Password: " + password);
                return true;
            }
        }
        return false;
    }

    // displays the trainer's information
    public boolean displayPersonalInfoT() throws SQLException {
        scanner = new Scanner(System.in);
        Statement statement = connection.createStatement();
        statement.executeQuery("SELECT *\n" +
                "FROM " + userType +
                "\nWHERE trainer_Id = " + id + ";");
        ResultSet resultSet = statement.getResultSet();
        System.out.println("Enter password to view: ");
        String password = scanner.nextLine();
        while (resultSet.next()) {
            if (password.equals(resultSet.getString("password"))) {
                // display the user information
                System.out.println("\nFirst name: " + resultSet.getString("first_name"));
                System.out.println("Last name: " + resultSet.getString("last_name"));
                System.out.println("Phone number: " + resultSet.getString("phone_number"));
                System.out.print("Gender: ");
                if ((resultSet.getString("gender")).charAt(0) == 'f')
                    System.out.println("female");
                else if ((resultSet.getString("gender")).charAt(0) == 'f')
                    System.out.println("male");
                else
                    System.out.println("other");
                System.out.println("Email: " + resultSet.getString("email"));
                System.out.println("Username: " + resultSet.getString("username"));
                System.out.println("Password: " + password);
                return true;
            }
        }
        return false;
    }

    // displays the member's information
    public boolean displayPersonalInfoA() throws SQLException {
        scanner = new Scanner(System.in);
        Statement statement = connection.createStatement();
        statement.executeQuery("SELECT *\n" +
                "FROM " + userType +
                "\nWHERE administrator_id = " + id + ";");
        ResultSet resultSet = statement.getResultSet();
        System.out.println("Enter password to view: ");
        String password = scanner.nextLine();
        while (resultSet.next()) {
            if (password.equals(resultSet.getString("password"))) {
                // display the user information
                System.out.println("\nFirst name: " + resultSet.getString("first_name"));
                System.out.println("Last name: " + resultSet.getString("last_name"));
                System.out.println("Phone number: " + resultSet.getString("phone_number"));
                System.out.println("Email: " + resultSet.getString("email"));
                System.out.println("Username: " + resultSet.getString("username"));
                System.out.println("Password: " + password);
                return true;
            }
        }
        return false;
    }

    // allow trainers to view members
    public void viewMembersT(String firstName, String lastName) throws SQLException {
        Statement statement = connection.createStatement();
        statement.executeQuery("SELECT *\n" +
                "FROM Members_View" +
                "\nWHERE first_name = '" + firstName + "' AND last_name = '" + lastName + "';");

        ResultSet resultSet = statement.getResultSet();
        if (!resultSet.next())
            System.out.println("This member does not exist in the system.");
        else {
            System.out.println("\nMember: ");
            System.out.println("First name: " + resultSet.getString("first_name"));
            System.out.println("Last name: " + resultSet.getString("last_name"));
            System.out.println("Email: " + resultSet.getString("email"));
            System.out.print("Gender: ");
            if ((resultSet.getString("gender")).charAt(0) == 'f')
                System.out.println("female");
            else if ((resultSet.getString("gender")).charAt(0) == 'f')
                System.out.println("male");
            else
                System.out.println("other");
            System.out.println("Age: " + resultSet.getString("age"));
        }
    }

    public void manageSessionsM() throws SQLException {
        Statement statement = connection.createStatement();
        statement.executeQuery("SELECT * \n" +
                "FROM Sessions JOIN Members ON Sessions.session_id = Members.session_id\n" +
                "WHERE member_id = " + id);
        ResultSet resultSet = statement.getResultSet();
        if (!resultSet.next()) {
            System.out.println("You are not registered in any session yet, would you like to?");
            String answer = scanner.nextLine();
            if (answer.equalsIgnoreCase("yes"))
                registerForSession();
        } else {
            System.out.print("Session type: ");
            if (resultSet.getString("training_type").charAt(0) == 'p')
                System.out.println("personal training");
            else
                System.out.println("group class");
            System.out.println("Session date: " + resultSet.getDate("session_date"));
        }
    }

    public void registerForSession() throws SQLException {
        Statement statement = connection.createStatement();
        System.out.println("Which session would you like to register for? (p- personal training or g- group class)");
        char session_type = scanner.next().charAt(0);

        displaySessions(session_type);
        System.out.println("Enter the ID of the session you would like to register to: ");
        int session_id = scanner.nextInt();

        statement.executeQuery("SELECT *\n" +
                "FROM Sessions\n" +
                "WHERE session_id = " + session_id);
        ResultSet resultSet = statement.getResultSet();
        if (resultSet.next()) {
            if (resultSet.getBoolean("available")) {
                String updateStatement = "UPDATE Members\n" +
                        "SET session_id = " + session_id +
                        "\nWHERE member_id = " + id + ";";
                int rowsUpdated = statement.executeUpdate(updateStatement);
                if (rowsUpdated > 0) {
                    System.out.println("You successfully registered!");
                    if (session_type == 'p') {
                        String updateStatement2 = "UPDATE Sessions\n" +
                                "SET available = " + false +
                                "\nWHERE member_id = " + id + ";";
                        int rowsUpdated2 = statement.executeUpdate(updateStatement2);
                        // add the personal training fee to the user's bill
                        String updateStatement3 = "UPDATE Bills\n" +
                                "SET personal_training_fee = " + getPersonalTrainingFee() +
                                "\nWHERE member_id = " + id;
                        int rowsUpdated3 = statement.executeUpdate(updateStatement3);
                        if (rowsUpdated3 > 0) {
                            System.out.println("Fees were added.");
                        }
                    } else if (session_type == 'g') {
                        // add the personal training fee to the user's bill
                        String updateStatement2 = "UPDATE Bills\n" +
                                "SET group_class_fee = " + getGroupClassFee() + "\n" +
                                "WHERE member_id = " + id;
                        int rowsUpdated2 = statement.executeUpdate(updateStatement2);
                        if (rowsUpdated2 > 0) {
                            System.out.println("Fees were added.");
                        }
                    } else {
                        System.out.println("Sorry this session does not exist.");
                    }
                } else
                    System.out.println("This session is already taken or it does not exist.");
            }
        }
    }

    public void displaySessions(char session) throws SQLException {
        Statement statement = connection.createStatement();
        statement.executeQuery("SELECT *\n" +
                "FROM Sessions LEFT OUTER JOIN Trainers ON Sessions.trainer_id = Trainers.trainer_id\n" +
                "WHERE training_type = " + session + ";");
        ResultSet resultSet = statement.getResultSet();
        while (resultSet.next()) {
            System.out.println("Session ID: " + resultSet.getInt("session_id"));
            System.out.println("Session date: " + resultSet.getDate("session_date"));
            System.out.print("Session type: ");
            if (session == 'p')
                System.out.println("personal training");
            else
                System.out.println("group class");
            System.out.println("Trainer name: " + resultSet.getString("first_name") + " " + resultSet.getString("last_name"));
            System.out.print("Trainer's gender: ");
            if ((resultSet.getString("gender")).charAt(0) == 'f')
                System.out.println("female");
            else if ((resultSet.getString("gender")).charAt(0) == 'f')
                System.out.println("male");
            else
                System.out.println("other");
        }
    }


    public void addSession() throws SQLException {
        Statement statement = connection.createStatement();
        statement.executeQuery("SELECT *\n" +
                                    "FROM Sessions\n" +
                                    "WHERE trainer_id = " + id + ";");
        ResultSet resultSet = statement.getResultSet();
        // availability doesn't exist
        if (!resultSet.next()) {
            System.out.println("You don't have any availability: ");
        }
        System.out.println("Would you like to add a session?");
        String answer = scanner.nextLine();
        if (answer.equalsIgnoreCase("yes")) {
            Scanner scanner2 = new Scanner(System.in);
            System.out.println("Which session would you like to add? (p- personal training or g- group class)");
            char training_type = scanner2.next().charAt(0);
            System.out.println("Enter your available date (YYYY-MM-DD): ");
            String dateInput = scanner2.nextLine();
            System.out.println("Enter your available date (HH:MM AM/PM): ");
            String timeInput = scanner2.nextLine();

            String dateTimeInput = dateInput + " " + timeInput;
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd h:m a");
            LocalDateTime availabilityDateTime = LocalDateTime.parse(dateTimeInput, formatter);
            Timestamp availabilityTimestamp = Timestamp.valueOf(availabilityDateTime);

            String insertedStatement = "INSERT INTO Sessions (session_date, training_type, trainer_id) VALUES\n" +
                                        "('" + availabilityTimestamp + "', '" + training_type + "', " + id + ", " + ");";
            int rowsInserted = statement.executeUpdate(insertedStatement);
            if (rowsInserted > 0)
                System.out.println("Your availability was added!");
            else
                System.out.println("Your availability was not added!");
        }
    }

    public void displayEquipments() throws SQLException {
        Statement statement = connection.createStatement();
        statement.executeQuery("SELECT *\n" +
                                    "FROM Equipments\n");

        ResultSet resultSet = statement.getResultSet();
        while(resultSet.next()) {
            System.out.println("Equipment ID: #E" + resultSet.getInt("equipment_id"));
            System.out.println("Equipment name: " + resultSet.getString("equipment_name"));
            System.out.println("Equipment status: " + resultSet.getString("equipment_status"));
            System.out.println("Room ID : #R" + resultSet.getInt("room_id"));
            System.out.println();
        }
    }

    public void addEquipment() throws SQLException {
        Statement statement = connection.createStatement();
        System.out.println("Enter the equipment's name: ");
        String name = scanner.nextLine();
        System.out.println("Enter the equipment's status (low- needs maintenance, medium- soon needs maintenance, high- no maintenance needed): ");
        String status = scanner.nextLine();
        displayRooms();
        System.out.println("Enter the room ID where the equipment is: ");
        int room_id = scanner.nextInt();
        if(status.equalsIgnoreCase("low") || status.equalsIgnoreCase("medium") || status.equalsIgnoreCase("high")) {
            String insertStatement = "INSERT INTO Equipments (equipment_name, equipment_status, room_id) VALUES \n" +
                                     "('" + name + "', " + status + ", " + room_id + ");";
            int rowInserted = statement.executeUpdate(insertStatement);
            if(rowInserted > 0)
                System.out.println("Equipment was added successfully.");
            else
                System.out.println("Equipment was not added.");
        }
    }

    // display the equipment based on the id
    public void displayEquipmentID(int equipment_id) throws SQLException {
        Statement statement = connection.createStatement();
        statement.executeQuery("SELECT *\n" +
                                   "FROM Equipments LEFT OUTER JOIN Rooms ON Equipments.room_id = Rooms.room_id\n" +
                                   "WHERE equipment_id = " + equipment_id + ";");

        ResultSet resultSet = statement.getResultSet();
        if(resultSet.next()) {
            System.out.println("Equipment ID: #E" + resultSet.getInt("equipment_id"));
            System.out.println("Equipment name: " + resultSet.getString("equipment_name"));
            System.out.println("Equipment status: " + resultSet.getString("equipment_status"));
            System.out.println("Room ID: " + resultSet.getInt("room_id"));
            System.out.println("Room : #R" + resultSet.getInt("room_number"));
        }
    }

    // modify the equipment
    public void modifyEquipment() throws SQLException {
        Statement statement = connection.createStatement();
        System.out.println("Which equipment would you like to modify? (enter the id)");
        int equipment_id = scanner.nextInt();
        displayEquipmentID(equipment_id);
        Scanner scanner1 = new Scanner(System.in);
        System.out.println("Which value would you like to change (name, status or both)?");
        String answer = scanner1.nextLine();
        if(answer.equalsIgnoreCase("name")) {
            System.out.println("Enter the new name: ");
            String name = scanner1.nextLine();
            String updatedStatement = "UPDATE Equipments\n" +
                                      "SET equipment_name = " + name +
                                      "\nWHERE equipment_id = " + equipment_id;
            int rowsUpdated = statement.executeUpdate(updatedStatement);
            if(rowsUpdated > 0)
                System.out.println("Equipment ID ( " + equipment_id + " ) was successfully updated.");
            else
                System.out.println("Equipment was not updated.");
        }
        else if (answer.equalsIgnoreCase("status")) {
            System.out.println("Enter the new status (low- needs maintenance, medium- soon needs maintenance, high- no maintenance needed): ");
            String status = scanner1.nextLine();
            String updatedStatement = "UPDATE Equipments\n" +
                                      "SET equipment_status = " + status +
                                      "\nWHERE equipment_id = " + equipment_id + ";";
            int rowsUpdated = statement.executeUpdate(updatedStatement);
            if(rowsUpdated > 0)
                System.out.println("Equipment ID ( " + equipment_id + " ) was successfully updated.");
            else
                System.out.println("Equipment was not updated.");
        }
        else if(answer.equalsIgnoreCase("both")) {
            System.out.println("Enter the new name: ");
            String name = scanner1.nextLine();
            System.out.println("Enter the new status (low- needs maintenance, medium- soon needs maintenance, high- no maintenance needed): ");
            String status = scanner1.nextLine();
            if(status.equalsIgnoreCase("low") || status.equalsIgnoreCase("medium") || status.equalsIgnoreCase("high")) {
                String updatedStatement = "UPDATE Equipments\n" +
                                          "SET equipment_name = " + name + ",\n" +
                                          "equipment_status = " + status +
                                          "\nWHERE equipment_id = " + equipment_id;
                int rowsUpdated = statement.executeUpdate(updatedStatement);
                if (rowsUpdated > 0)
                    System.out.println("Equipment ID ( " + equipment_id + " ) was successfully updated.");
                else
                    System.out.println("Equipment was not updated.");
            }
        }
        else {
            System.out.println("This entry does not exist.");
        }

        System.out.println("Would you like to update the room too?");
        answer = scanner1.nextLine();
        if(answer.equalsIgnoreCase("yes")) {
            System.out.println("Enter the room Id: ");
            int room_id = scanner1.nextInt();
            String updateStatement = "UPDATE Equipments\n" +
                                     "SET room_id = " + room_id +
                                     "\nWHERE equipment_id = " + equipment_id + ";";
            int rowsUpdated = statement.executeUpdate(updateStatement);
            if(rowsUpdated > 0) {
                System.out.println("Equipment was change to a new room.");
            }
        }
    }

    // delete the equipment
    public void deleteEquipment() throws  SQLException {
        Statement statement = connection.createStatement();
        System.out.println("Enter the equipment id that you want to delete: ");
        int equipment_id = scanner.nextInt();
        String deleteStatement = "DELETE FROM Equipments\n" +
                                 "WHERE equipment_id = '" + equipment_id + "';";

        int rowsDeleted = statement.executeUpdate(deleteStatement);
        // if rows were deleted
        if (rowsDeleted > 0)
            System.out.println("Equipment ID ( " + equipment_id + " ) was deleted successfully!");
        else
            System.out.println("Equipment was not deleted.");
    }

    public void bookRoom() throws SQLException {
        Statement statement = connection.createStatement();
        statement.executeQuery("SELECT *\n" +
                                   "FROM Sessions");
        ResultSet resultSet = statement.getResultSet();
        while(resultSet.next()) {
            int session_id = resultSet.getInt("session_id");
            System.out.println("Session ID: " + session_id);
            System.out.println("Session date: " + resultSet.getDate("session_date"));
            System.out.println("Type: " + resultSet.getString("training_type"));
            System.out.println("Trainer ID: " + resultSet.getString("trainer_id"));

            System.out.println("Room ID: " + resultSet.getInt("room_id"));
            System.out.println("Would you like to modify this?");
            String answer = scanner.nextLine();
            if(answer.equalsIgnoreCase("yes")) {
                displayRooms();
                System.out.println("Enter the room id: ");
                int room_id = scanner.nextInt();
                String updateStatement = "UPDATE Sessions\n" +
                                         "SET room_id = " + room_id +
                                         "\nWHERE session_id = " + session_id + ";";
                int rowsUpdated = statement.executeUpdate(updateStatement);
                if(rowsUpdated > 0)
                    System.out.println("Room successfully booked!");
                else
                    System.out.println("Sorry this Room ID does not exist.");
            }
        }
    }

    public void displayRooms() throws SQLException {
        Statement statement = connection.createStatement();
        statement.executeQuery("SELECT *\n" +
                                    "FROM Rooms");
        ResultSet resultSet = statement.getResultSet();
        while(resultSet.next()) {
            System.out.println("Room ID: " + resultSet.getInt("room_id"));
            System.out.println("Room #: " + resultSet.getInt("room_number"));
            System.out.println("Room name: " + resultSet.getString("room_name"));
        }
    }
}

